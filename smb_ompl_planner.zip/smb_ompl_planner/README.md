## smb_ompl_planner  
This package contains a global planner based on the [OMPL library](http://ompl.kavrakilab.org/) and the `move_base` navigation stack. Refer to the tutorial slides in order to be able to use it.
